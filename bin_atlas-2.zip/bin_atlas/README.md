# BIN Atlas v1.2

BIN lookup, issuer search and Luhn practice. Flet (Python), builds to Android.

## Tabs
- **Lookup** - one or many BINs (comma separated, 6 to 8 digits each). Results appear as soon as each one is ready.
  Card: scheme, type, tier, Luhn, issuer, country, currency. Save a number with a note (note field is under the card).
- **Banks** - bincheck.io-style cascading filters (Country > Brand > Bank > Type > Level), Search / Reset,
  "Find a bank", paging, Export TXT. Tap **Download BIN database** once to load every country and bank offline.
- **Learn** - multi-number Luhn checker with step-by-step explanation (on-device, nothing stored, long numbers masked).
- **Saved** - saved numbers (exactly as searched, up to 8 digits) with notes, save time and history. Export TXT.

## Digits
At most the first 8 digits (the BIN/IIN) are sent, shown, saved or exported. Extra digits are dropped silently.
The 6-digit BIN is shown in small gray text under any 7-8 digit number.

## Speed
Shared keep-alive connections + pre-warm, sources tried with automatic failover (the next source starts
if one is slow or fails), cached/offline answers shown instantly and upgraded in the background,
several BINs resolved in parallel, missing fields filled in the background.

## Sources and keys
binlist.io -> HandyAPI -> binlist.net. Never put keys in code or the repo: open the app > gear icon > paste
your binlist.io key (bl_...) and HandyAPI **publishable** key (PUB-...). The secret key (HAS-...) is refused.

## TXT export format
    -----------------------------------------------------
    DATE : 16/10/2026
    TIME : 12:54
    -----------------------------------------------------
    52792622
    TYPE / BANK / COUNTRY / INFO (level - type - scheme) / NOTE lines
Entries saved in the same minute share one DATE/TIME header; otherwise a new header starts.

## Run / test / build
    pip install flet==0.28.3 requests
    python main.py
    python -m unittest test_engine test_ui_smoke -v
    flet build apk --project "BIN Atlas" --org com.binatlas

## Credits
Offline BIN database: venelinkochev/bin-list-data (CC BY 4.0). Public BIN data may be incomplete or outdated.
