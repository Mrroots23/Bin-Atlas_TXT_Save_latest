"""BIN Atlas - data engine v3 (no UI dependencies, unit-testable).

Speed:   shared keep-alive HTTP session, connection pre-warm, "hedged" provider
         requests (the next provider starts if the first is slow or fails), instant
         local answers refreshed in the background, background gap-filling.
Sources: binlist.io -> HandyAPI -> binlist.net (automatic failover) plus an optional
         offline BIN database (venelinkochev/bin-list-data, CC BY 4.0).
Privacy: at most the first 8 digits (the BIN/IIN) are ever sent or stored.
Keys:    never in source code; entered by the user in Settings (private storage).
"""
from __future__ import annotations

import csv
import os
import queue
import re
import sqlite3
import threading
import time
from contextlib import closing
from datetime import datetime, timedelta

import requests
import requests.adapters

MAX_QUERY_DIGITS = 8                 # BIN/IIN length; nothing longer is kept
CACHE_TTL_DAYS = 90
NEG_CACHE_HOURS = 24
HTTP_TIMEOUT = (3.5, 5)              # connect, read (seconds) - fail fast, fail over
HEDGE_DELAY = 1.2                    # start the next provider if no answer by then
HTTP_WAIT_MAX = 12
USER_AGENT = "BINAtlas/1.2 (educational app)"
SAMPLE_SOURCE = "Sample data"
IMPORT_SOURCE = "Imported CSV"
OFFLINE_SOURCES = (SAMPLE_SOURCE, IMPORT_SOURCE)
DATASET_URL = "https://raw.githubusercontent.com/venelinkochev/bin-list-data/master/bin-list-data.csv"
DATASET_CREDIT = "Offline BIN database: venelinkochev/bin-list-data (CC BY 4.0)"
TS_FMT = "%Y-%m-%d %H:%M:%S"
NA_VALUES = (None, "", "N/A", "UNKNOWN")
COMMERCIAL_WORDS = ("BUSINESS", "CORPORATE", "COMMERCIAL")
SCHEME_DISPLAY = {"AMEX": "AMERICAN EXPRESS"}

# Column semantics (unchanged): scheme = card network ("Brand" on bincheck.io),
# brand = product level/tier.
FIELDS = ["scheme", "type", "brand", "bank", "phone", "url", "country",
          "country_code", "country_a3", "continent", "dial_code", "currency",
          "prepaid", "commercial", "luhn"]
FILTER_COLUMNS = ("country_code", "scheme", "bank", "type", "brand")
BIN_COLUMNS = ["bin"] + FIELDS + ["source", "fetched_at"]
BIN_SELECT = ",".join(f"b.{c}" for c in BIN_COLUMNS)

SCHEMA_COLUMNS = (
    [("bin", "TEXT PRIMARY KEY")]
    + [(f, "TEXT DEFAULT 'N/A'") for f in FIELDS]
    + [("source", "TEXT"), ("fetched_at", "TEXT"), ("looked_up_at", "TEXT"),
       ("lookup_count", "INTEGER DEFAULT 0"), ("favorite", "INTEGER DEFAULT 0"),
       ("note", "TEXT DEFAULT ''"), ("saved_at", "TEXT")]
)
BULK_INDEXES = {
    "idx_bins_country": "bins(country_code)",
    "idx_bins_filters": "bins(country_code, scheme, bank, type, brand)",
    "idx_bins_bank": "bins(bank)",
}

COOLDOWN_SECONDS = {
    "ratelimited": {"binlist.io": 60, "handyapi": 30, "binlist.net": 900},
    "error": 45,
    "auth": 600,
}
OUTCOME_LABEL = {"ok": "ok", "notfound": "no data", "ratelimited": "rate limit",
                 "auth": "key rejected", "error": "unreachable", "cooldown": "paused"}
OUTCOME_MESSAGE = {
    "notfound": "No provider has data for this BIN.",
    "ratelimited": "Provider rate limit reached. Try again shortly.",
    "auth": "An API key was rejected. Check the keys in Settings.",
    "error": "Could not reach the data providers (offline?).",
}

# One shared session = TLS/TCP connections are reused (big win on mobile networks).
_SESSION = requests.Session()
_SESSION.mount("https://", requests.adapters.HTTPAdapter(pool_connections=6, pool_maxsize=12, max_retries=0))


def _http_get(url, headers=None, timeout=HTTP_TIMEOUT, stream=False):
    return _SESSION.get(url, headers=headers, timeout=timeout, stream=stream)


def _http_head(url, timeout=3):
    return _SESSION.head(url, timeout=timeout)


def default_data_dir() -> str:
    base = os.environ.get("FLET_APP_STORAGE_DATA") or os.path.join(
        os.path.expanduser("~"), ".bin_atlas")
    os.makedirs(base, exist_ok=True)
    return base


# ----------------------------------------------------------------------
# Pure helpers
# ----------------------------------------------------------------------
def normalize_query(text: str) -> str:
    """Digits only, capped at 8. Everything after the 8th digit is discarded."""
    return re.sub(r"\D", "", text or "")[:MAX_QUERY_DIGITS]


def extract_queries(text: str, limit: int = 20) -> list[str]:
    """Unique 6-8 digit queries from free text (comma / Arabic comma / ; / newline,
    or space-separated groups when every group has >= 6 digits)."""
    out: list[str] = []
    for token in re.split(r"[,\u060c;\n]+", text or ""):
        parts = token.split()
        if len(parts) > 1 and all(len(re.sub(r"\D", "", p)) >= 6 for p in parts):
            candidates = parts
        else:
            candidates = [token]
        for cand in candidates:
            q = normalize_query(cand)
            if len(q) >= 6 and q not in out:
                out.append(q)
    return out[:limit]


def flag_emoji(country_code: str) -> str:
    if not country_code or len(country_code) != 2 or not country_code.isalpha():
        return "\U0001F310"
    return "".join(chr(127397 + ord(c)) for c in country_code.upper())


def detect_scheme(prefix: str) -> tuple[str, str]:
    """Guess the card network from leading digits (offline fallback)."""
    p = re.sub(r"\D", "", prefix or "")
    if not p:
        return "UNKNOWN", ""

    def in_range(k: int, lo: int, hi: int) -> bool:
        return len(p) >= k and lo <= int(p[:k]) <= hi

    if p[:2] in ("34", "37"):
        return "AMEX", "15"
    if in_range(4, 3528, 3589):
        return "JCB", "16-19"
    if in_range(3, 300, 305) or p[:2] in ("36", "38", "39"):
        return "DINERS CLUB", "14-19"
    if p.startswith("6011") or in_range(3, 644, 649) or p.startswith("65"):
        return "DISCOVER", "16-19"
    if p.startswith("62"):
        return "UNIONPAY", "16-19"
    if in_range(4, 2200, 2204):
        return "MIR", "16-19"
    if p[:2] in ("51", "52", "53", "54", "55") or in_range(4, 2221, 2720):
        return "MASTERCARD", "16"
    if p.startswith(("5018", "5020", "5038", "5893", "6304", "6759",
                     "6761", "6762", "6763")):
        return "MAESTRO", "12-19"
    if p.startswith("4"):
        return "VISA", "13, 16 or 19"
    return "UNKNOWN", ""


LENGTHS = {
    "VISA": {13, 16, 19}, "MASTERCARD": {16}, "AMEX": {15},
    "DINERS CLUB": set(range(14, 20)), "DISCOVER": set(range(16, 20)),
    "JCB": set(range(16, 20)), "UNIONPAY": set(range(16, 20)),
    "MIR": set(range(16, 20)), "MAESTRO": set(range(12, 20)),
}


def length_ok(scheme: str, n: int):
    allowed = LENGTHS.get(scheme)
    return None if allowed is None else n in allowed


def luhn_steps(number: str):
    """Explain the Luhn checksum step by step (education only)."""
    digits = [int(c) for c in re.sub(r"\D", "", number or "")]
    if len(digits) < 2:
        return None
    steps, total = [], 0
    for idx, d in enumerate(reversed(digits)):
        doubled = idx % 2 == 1
        value = d * 2 if doubled else d
        if value > 9:
            value -= 9
        total += value
        steps.append({"digit": d, "doubled": doubled, "value": value})
    steps.reverse()
    return {"steps": steps, "total": total, "valid": total % 10 == 0}


def mask_number(digits: str) -> str:
    n = len(digits)
    if n < 13:
        return digits
    return digits[:6] + "\u2022" * (n - 10) + digits[-4:]


def luhn_batch(text: str, limit: int = 25) -> dict:
    """Check several numbers at once. Pure checksum, on-device, nothing stored."""
    tokens = [t for t in re.split(r"[,\n;\u060c]+", text or "") if t.strip()]
    truncated = len(tokens) > limit
    items = []
    for i, tok in enumerate(tokens[:limit], 1):
        digits = re.sub(r"\D", "", tok)
        item = {"index": i, "digits": digits, "masked": mask_number(digits),
                "length": len(digits), "valid": None, "scheme": "UNKNOWN",
                "length_ok": None, "error": "", "total": None}
        if len(digits) < 2:
            item["error"] = "Too short"
        elif len(digits) > 19:
            item["error"] = "Longer than 19 digits"
        else:
            res = luhn_steps(digits)
            item["valid"], item["total"] = res["valid"], res["total"]
            item["scheme"] = detect_scheme(digits)[0]
            item["length_ok"] = length_ok(item["scheme"], len(digits))
        items.append(item)
    return {"items": items, "truncated": truncated,
            "passed": sum(1 for x in items if x["valid"] is True),
            "failed": sum(1 for x in items if x["valid"] is False)}


def _up(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s.upper() if s else default


def _txt(v, default="N/A") -> str:
    s = str(v).strip() if v not in (None, "") else ""
    return s or default


def _yn(v, default="Unknown") -> str:
    return "Yes" if v is True else ("No" if v is False else default)


def _is_na(v) -> bool:
    return v in NA_VALUES


def _fmt_time(ts: str, fallback: datetime | None = None) -> tuple[str, str]:
    """'YYYY-MM-DD HH:MM:SS' -> ('DD/MM/YYYY', 'HH:MM')."""
    try:
        t = datetime.strptime(ts, TS_FMT)
    except (TypeError, ValueError):
        t = fallback or datetime.now()
    return t.strftime("%d/%m/%Y"), t.strftime("%H:%M")


# ----------------------------------------------------------------------
# Engine
# ----------------------------------------------------------------------
class BinEngine:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or os.path.join(default_data_dir(), "bin_atlas.db")
        self._cool: dict[str, float] = {}
        self._cool_reason: dict[str, str] = {}
        self._init_db()

    # -- storage -------------------------------------------------------
    def _q(self, sql: str, params=(), one: bool = False):
        with closing(sqlite3.connect(self.db_path, timeout=15)) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(sql, params)
            result = cur.fetchone() if one else cur.fetchall()
            conn.commit()
        if one:
            return dict(result) if result else None
        return [dict(r) for r in result]

    def _init_db(self):
        cols = ",".join(f"{n} {ddl}" for n, ddl in SCHEMA_COLUMNS)
        self._q(f"CREATE TABLE IF NOT EXISTS bins ({cols})")
        have = {r["name"] for r in self._q("PRAGMA table_info(bins)")}
        for name, ddl in SCHEMA_COLUMNS:           # migration from older app versions
            if name not in have:
                self._q(f"ALTER TABLE bins ADD COLUMN {name} {ddl}")
        self._q("CREATE TABLE IF NOT EXISTS misses (bin TEXT PRIMARY KEY, ts TEXT)")
        self._q("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        self._q("CREATE TABLE IF NOT EXISTS searches (query TEXT PRIMARY KEY, bin TEXT, ts TEXT)")
        self._q("CREATE TABLE IF NOT EXISTS saved (query TEXT PRIMARY KEY, bin TEXT, "
                "note TEXT DEFAULT '', saved_at TEXT)")
        self._q("CREATE INDEX IF NOT EXISTS idx_searches_ts ON searches(ts)")
        self._q("CREATE INDEX IF NOT EXISTS idx_saved_at ON saved(saved_at)")
        self._create_bulk_indexes()
        if self._q("SELECT COUNT(*) AS n FROM bins", one=True)["n"] == 0:
            # Tiny bundled sample so the app works offline on first run.
            # Illustrative and UNVERIFIED; live data or the offline database replaces it.
            seed = [
                ("440393", "VISA", "DEBIT", "PREPAID CLASSIC", "SUTTON BANK", "UNITED STATES", "US", "USD"),
                ("405542", "VISA", "CREDIT", "CLASSIC", "PT. BANK DBS INDONESIA", "INDONESIA", "ID", "IDR"),
                ("408353", "VISA", "DEBIT", "CLASSIC", "JPMORGAN CHASE BANK, N.A.", "UNITED STATES", "US", "USD"),
                ("424242", "VISA", "CREDIT", "CLASSIC", "STRIPE TEST BANK", "UNITED STATES", "US", "USD"),
                ("510510", "MASTERCARD", "CREDIT", "STANDARD", "MASTERCARD TEST ISSUER", "UNITED STATES", "US", "USD"),
                ("378282", "AMEX", "CREDIT", "CORPORATE", "AMERICAN EXPRESS COMPANY", "UNITED STATES", "US", "USD"),
                ("526412", "MASTERCARD", "DEBIT", "PLATINUM", "AL RAJHI BANK", "SAUDI ARABIA", "SA", "SAR"),
            ]
            with closing(sqlite3.connect(self.db_path)) as conn:
                for b, scheme, typ, brand, bank, country, cc, cur in seed:
                    conn.execute(
                        "INSERT OR IGNORE INTO bins (bin,scheme,type,brand,bank,country,country_code,currency,source) "
                        "VALUES (?,?,?,?,?,?,?,?,?)",
                        (b, scheme, typ, brand, bank, country, cc, cur, SAMPLE_SOURCE))
                conn.commit()
        self._migrate_v3()

    def _migrate_v3(self):
        """v1.1 kept saved/history flags on the bins table; v1.2 keeps them per searched number."""
        if self.get_setting("migrated_v3") == "1":
            return
        now = self._now()
        self._q("INSERT OR IGNORE INTO saved (query, bin, note, saved_at) "
                "SELECT bin, bin, COALESCE(note,''), COALESCE(saved_at, ?) FROM bins WHERE favorite=1", (now,))
        self._q("INSERT OR IGNORE INTO searches (query, bin, ts) "
                "SELECT bin, bin, looked_up_at FROM bins WHERE looked_up_at IS NOT NULL")
        self.set_setting("migrated_v3", "1")

    def _create_bulk_indexes(self):
        for name, target in BULK_INDEXES.items():
            self._q(f"CREATE INDEX IF NOT EXISTS {name} ON {target}")

    def _drop_bulk_indexes(self):
        for name in BULK_INDEXES:
            self._q(f"DROP INDEX IF EXISTS {name}")

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime(TS_FMT)

    def count(self) -> int:
        return self._q("SELECT COUNT(*) AS n FROM bins", one=True)["n"]

    def _row(self, b: str):
        return self._q("SELECT * FROM bins WHERE bin=?", (b,), one=True)

    # -- settings / keys ----------------------------------------------
    def get_setting(self, key: str, default: str = "") -> str:
        row = self._q("SELECT value FROM settings WHERE key=?", (key,), one=True)
        return row["value"] if row and row["value"] is not None else default

    def set_setting(self, key: str, value: str):
        self._q("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))

    def set_api_keys(self, handyapi: str = "", binlistio: str = "") -> list[str]:
        """Validate and store keys. Returns a list of problems (empty = saved)."""
        handyapi, binlistio = (handyapi or "").strip(), (binlistio or "").strip()
        problems = []
        if handyapi.upper().startswith("HAS-"):
            problems.append("That HandyAPI key is the SECRET key (HAS-...). A mobile app "
                            "must only use the publishable key (PUB-...).")
        for label, key in (("HandyAPI", handyapi), ("binlist.io", binlistio)):
            if re.search(r"\s", key):
                problems.append(f"The {label} key contains spaces. Paste it again.")
        if problems:
            return problems
        self.set_setting("handyapi_key", handyapi)
        self.set_setting("binlistio_key", binlistio)
        self._cool.clear()
        self._cool_reason.clear()
        return []

    def has_keys(self) -> bool:
        return bool(self.get_setting("handyapi_key") or self.get_setting("binlistio_key"))

    # -- providers ----------------------------------------------------
    def prewarm(self):
        """Open DNS/TLS connections in the background so the first lookup is fast."""
        def work():
            for url in ("https://binlist.io/", "https://data.handyapi.com/", "https://lookup.binlist.net/"):
                try:
                    _http_head(url)
                except Exception:
                    pass
        threading.Thread(target=work, daemon=True).start()

    def _get_json(self, url: str, headers: dict | None = None):
        hdr = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        hdr.update(headers or {})
        try:
            r = _http_get(url, hdr, HTTP_TIMEOUT)
        except requests.RequestException:
            return None, "error"
        if r.status_code == 404:
            return None, "notfound"
        if r.status_code == 429:
            return None, "ratelimited"
        if r.status_code in (401, 403):
            return None, "auth"
        if r.status_code != 200:
            return None, "error"
        try:
            return r.json(), "ok"
        except ValueError:
            return None, "error"

    @staticmethod
    def _from_binlist_shape(b: str, d: dict, source: str):
        """binlist.net and binlist.io share this JSON layout. `or {}` is deliberate:
        these APIs return "bank": null for many BINs."""
        bank = d.get("bank") or {}
        if not isinstance(bank, dict):
            bank = {"name": bank}
        country = d.get("country") or {}
        if not isinstance(country, dict):
            country = {"name": country}
        number = d.get("number") or {}
        brand = _up(d.get("brand"))
        rec = {
            "bin": b, "source": source,
            "scheme": _up(d.get("scheme")), "type": _up(d.get("type")), "brand": brand,
            "bank": _up(bank.get("name")), "phone": _txt(bank.get("phone")),
            "url": _txt(bank.get("url")),
            "country": _up(country.get("name")),
            "country_code": _up(country.get("alpha2"), ""),
            "country_a3": _up(country.get("alpha3")),
            "continent": "N/A", "dial_code": "N/A",
            "currency": _up(country.get("currency")),
            "prepaid": _yn(d.get("prepaid")),
            "commercial": "Yes" if any(k in brand for k in COMMERCIAL_WORDS) else "Unknown",
            "luhn": _yn(number.get("luhn") if isinstance(number, dict) else None, "N/A"),
        }
        useful = any(not _is_na(rec[f]) for f in ("scheme", "type", "bank", "country"))
        return rec if useful else None

    def _binlistio(self, b: str):
        key = self.get_setting("binlistio_key")
        d, outcome = self._get_json(f"https://binlist.io/lookup/{b}/",
                                    {"X-API-Key": key} if key else None)
        if outcome != "ok":
            return None, outcome
        if not isinstance(d, dict):
            return None, "error"
        if d.get("success") is False:
            return None, "notfound"
        rec = self._from_binlist_shape(b, d, "binlist.io")
        return (rec, "ok") if rec else (None, "error")

    def _handyapi(self, b: str):
        key = self.get_setting("handyapi_key")
        d, outcome = self._get_json(f"https://data.handyapi.com/bin/{b}",
                                    {"x-api-key": key} if key else None)
        if outcome != "ok":
            return None, outcome
        if not isinstance(d, dict):
            return None, "error"
        status = str(d.get("Status", "")).upper()
        if status != "SUCCESS":
            # Only an explicit "not found" is a miss; a demo limit or hiccup must not poison the cache.
            return None, ("notfound" if "NOT" in status and "FOUND" in status else "error")
        country = d.get("Country") or {}
        tier = _up(d.get("CardTier"))
        isd = str(country.get("ISD") or "").strip()
        return {
            "bin": b, "source": "handyapi",
            "scheme": _up(d.get("Scheme")), "type": _up(d.get("Type")), "brand": tier,
            "bank": _up(d.get("Issuer")), "phone": "N/A", "url": "N/A",
            "country": _up(country.get("Name")), "country_code": _up(country.get("A2"), ""),
            "country_a3": _up(country.get("A3")), "continent": _up(country.get("Cont")),
            "dial_code": f"+{isd}" if isd else "N/A",
            "currency": "N/A",
            "prepaid": "Yes" if "PREPAID" in tier else "Unknown",
            "commercial": "Yes" if any(k in tier for k in COMMERCIAL_WORDS) else "Unknown",
            "luhn": _yn(d.get("Luhn"), "N/A"),
        }, "ok"

    def _binlistnet(self, b: str):
        d, outcome = self._get_json(f"https://lookup.binlist.net/{b}", {"Accept-Version": "3"})
        if outcome != "ok":
            return None, outcome
        rec = self._from_binlist_shape(b, d, "binlist.net") if isinstance(d, dict) else None
        return (rec, "ok") if rec else (None, "error")

    def _providers(self):
        return [("binlist.io", self._binlistio), ("handyapi", self._handyapi),
                ("binlist.net", self._binlistnet)]

    # failover bookkeeping
    def _cooling(self, name: str) -> bool:
        return self._cool.get(name, 0) > time.time()

    def _penalize(self, name: str, outcome: str):
        if outcome == "ratelimited":
            secs = COOLDOWN_SECONDS["ratelimited"].get(name, 60)
        elif outcome in ("auth", "error"):
            secs = COOLDOWN_SECONDS[outcome]
        else:
            return
        self._cool[name] = time.time() + secs
        self._cool_reason[name] = outcome

    @staticmethod
    def _merge(base: dict, extra: dict) -> dict:
        out = dict(base)
        for f in FIELDS:
            if _is_na(out.get(f)) and not _is_na(extra.get(f)):
                out[f] = extra[f]
        out["source"] = f"{base['source']} + {extra['source']}"
        return out

    @staticmethod
    def _needs_fill(rec: dict) -> bool:
        return any(_is_na(rec.get(f)) for f in ("type", "bank", "brand"))

    @staticmethod
    def _summarize(outcomes: list[str]) -> str:
        for pick in ("notfound", "ratelimited", "auth"):
            if pick in outcomes:
                return pick
        return "error"

    def _fetch_online(self, b: str):
        """Hedged failover: ask the best provider; if it fails start the next at once,
        and if it is merely slow start the next after HEDGE_DELAY. First good answer wins.
        Returns (record | None, outcome, trail[(name, outcome, seconds)])."""
        everything = self._providers()
        active = [(n, fn) for n, fn in everything if not self._cooling(n)]
        info = {n: ("cooldown", 0.0) for n, _ in everything if self._cooling(n)}

        def trail():
            return [(n, *info[n]) for n, _ in everything if n in info]

        if not active:
            reasons = [self._cool_reason.get(n) for n, _ in everything]
            return None, self._summarize([r for r in reasons if r in ("ratelimited", "auth")]), trail()

        results: queue.Queue = queue.Queue()

        def run(name, fn):
            t0 = time.time()
            try:
                rec, outcome = fn(b)
            except Exception:
                rec, outcome = None, "error"
            results.put((name, rec, outcome, time.time() - t0))

        started = 0

        def launch():
            nonlocal started
            name, fn = active[started]
            threading.Thread(target=run, args=(name, fn), daemon=True).start()
            started += 1

        launch()
        done, winner = 0, None
        while done < started or started < len(active):
            wait = HEDGE_DELAY if started < len(active) else HTTP_WAIT_MAX
            try:
                name, rec, outcome, dt = results.get(timeout=wait)
            except queue.Empty:
                if started < len(active):
                    launch()                       # first provider is slow: race the next one
                    continue
                break
            done += 1
            info[name] = (outcome, dt)
            if outcome == "ok":
                winner = rec
                break
            self._penalize(name, outcome)
            if started < len(active) and done == started:
                launch()                           # nothing in flight: fail over immediately
        if winner:
            return winner, "ok", trail()
        return None, self._summarize([o for o, _ in info.values()]), trail()

    @staticmethod
    def _trail_text(trail) -> str:
        parts = []
        for name, outcome, dt in trail:
            label = OUTCOME_LABEL.get(outcome, outcome)
            parts.append(f"{name}: {label}" + (f" {dt:.1f}s" if dt and outcome != "cooldown" else ""))
        return "  \u2192  ".join(parts)

    def _fill_gaps(self, rec: dict) -> dict:
        """Ask one more provider for fields the first one lacked (type, tier, issuer)."""
        for name, fn in self._providers():
            if name == rec["source"].split(" + ")[0] or self._cooling(name):
                continue
            got, outcome = fn(rec["bin"])
            if outcome == "ok":
                return self._merge(rec, got)
            self._penalize(name, outcome)
        return rec

    def test_providers(self) -> dict:
        """Connectivity/key check for Settings. Uses a public test BIN."""
        out = {}
        for name, fn in self._providers():
            t0 = time.time()
            rec, outcome = fn("424242")
            ok = outcome == "ok"
            if ok:
                self._cool.pop(name, None)
                self._cool_reason.pop(name, None)
            out[name] = (ok, f"working ({time.time() - t0:.1f}s)" if ok else OUTCOME_LABEL.get(outcome, outcome))
        return out

    # -- cache logic --------------------------------------------------
    def _is_fresh(self, row: dict) -> bool:
        if row.get("source") in OFFLINE_SOURCES or not row.get("fetched_at"):
            return False
        try:
            age = datetime.now() - datetime.strptime(row["fetched_at"], TS_FMT)
        except ValueError:
            return False
        return age < timedelta(days=CACHE_TTL_DAYS)

    def _status_of(self, row: dict) -> str:
        if row["source"] == SAMPLE_SOURCE:
            return "sample"
        if row["source"] == IMPORT_SOURCE:
            return "offline_db"
        return "cached" if self._is_fresh(row) else "stale"

    def _recent_miss(self, b: str) -> bool:
        row = self._q("SELECT ts FROM misses WHERE bin=?", (b,), one=True)
        if not row:
            return False
        try:
            return datetime.now() - datetime.strptime(row["ts"], TS_FMT) < timedelta(hours=NEG_CACHE_HOURS)
        except ValueError:
            return False

    def _upsert(self, rec: dict):
        b = rec["bin"]
        values = [rec.get(f, "N/A") for f in FIELDS]
        if self._row(b):
            self._q("UPDATE bins SET " + ",".join(f"{f}=?" for f in FIELDS) +
                    ",source=?,fetched_at=? WHERE bin=?",
                    values + [rec["source"], self._now(), b])
        else:
            self._q("INSERT INTO bins (bin," + ",".join(FIELDS) + ",source,fetched_at) VALUES (?" +
                    ",?" * (len(FIELDS) + 2) + ")", [b] + values + [rec["source"], self._now()])
        self._q("DELETE FROM misses WHERE bin=?", (b,))

    def _result(self, q: str, row: dict, status: str, message: str = "", trail: str = "",
                elapsed: float = 0.0, refreshing: bool = False) -> dict:
        scheme, lengths = detect_scheme(q)
        res = dict(row)
        for f in FIELDS:
            if res.get(f) is None:
                res[f] = "N/A"
        sv = self._q("SELECT note, saved_at FROM saved WHERE query=?", (q,), one=True)
        res.update({"found": True, "query": q, "status": status, "message": message, "trail": trail,
                    "elapsed": elapsed, "refreshing": refreshing,
                    "flag": flag_emoji(row.get("country_code", "")),
                    "detected_scheme": scheme, "expected_length": lengths,
                    "saved": sv is not None, "note": (sv or {}).get("note") or "",
                    "saved_at": (sv or {}).get("saved_at") or ""})
        return res

    def _record_search(self, q: str, b: str):
        self._q("INSERT OR REPLACE INTO searches (query, bin, ts) VALUES (?,?,?)", (q, b, self._now()))

    # -- online update (shared by sync and background paths) -----------
    def _fetch_and_store(self, b: str):
        """Returns (ok, message, trail_text, record_needing_gap_fill | None)."""
        rec, outcome, trail = self._fetch_online(b)
        trail_text = self._trail_text(trail)
        if rec:
            self._upsert(rec)
            fill = rec if (self.get_setting("combine", "1") == "1" and self._needs_fill(rec)) else None
            return True, "", trail_text, fill
        if trail and all(o == "notfound" for _, o, _ in trail):    # every provider was asked and said "unknown"
            self._q("INSERT OR REPLACE INTO misses (bin, ts) VALUES (?,?)", (b, self._now()))
        return False, OUTCOME_MESSAGE.get(outcome, "No data found."), trail_text, None

    def _refresh_in_background(self, q: str, on_update):
        b, t0 = q[:6], time.time()
        try:
            ok, message, trail_text, fill = self._fetch_and_store(b)
            row = self._row(b)
            on_update(self._result(q, row, "live" if ok else self._status_of(row), message,
                                   trail_text, time.time() - t0))
            if fill:
                merged = self._fill_gaps(fill)
                if merged is not fill:
                    self._upsert(merged)
                    on_update(self._result(q, self._row(b), "live", "", trail_text, time.time() - t0))
        except Exception as exc:                                     # never crash the UI thread pool
            row = self._row(b)
            if row:
                on_update(self._result(q, row, self._status_of(row), f"Update failed: {exc}"))

    def _gap_fill_in_background(self, q: str, rec: dict, trail_text: str, on_update, t0: float):
        try:
            merged = self._fill_gaps(rec)
            if merged is not rec:
                self._upsert(merged)
                on_update(self._result(q, self._row(rec["bin"]), "live", "", trail_text, time.time() - t0))
        except Exception:
            pass

    # -- public lookup API --------------------------------------------
    def lookup(self, text: str, allow_network: bool = True, force_refresh: bool = False,
               on_update=None) -> dict:
        """Look up one BIN (6-8 digits). With `on_update`, slow follow-up work (refreshing
        offline/stale rows, filling missing fields) runs in the background and calls
        on_update(new_result) when done; without it everything completes before returning."""
        q = normalize_query(text)
        b = q[:6]
        scheme, lengths = detect_scheme(b)
        result = {"query": q, "bin": b, "found": False, "status": "", "message": "", "trail": "",
                  "elapsed": 0.0, "refreshing": False, "saved": False, "note": "",
                  "detected_scheme": scheme, "expected_length": lengths, "flag": flag_emoji("")}
        if len(b) < 6:
            result["message"] = "Enter at least 6 digits."
            return result

        t0 = time.time()
        row = self._row(b)
        need_net = allow_network and (force_refresh or row is None or not self._is_fresh(row))
        message, trail_text, status, refreshing = "", "", None, False

        if need_net and not force_refresh and self._recent_miss(b):
            need_net, message = False, "No provider had data for this BIN in the last 24 hours."
        if not allow_network:
            message = "Offline mode: showing local data only."

        if need_net and row is not None and not force_refresh and on_update is not None:
            refreshing = True                                       # answer now, upgrade in background
            threading.Thread(target=self._refresh_in_background, args=(q, on_update), daemon=True).start()
        elif need_net:
            ok, message, trail_text, fill = self._fetch_and_store(b)
            row = self._row(b)
            if ok:
                status = "live"
                if fill and on_update is not None:
                    threading.Thread(target=self._gap_fill_in_background,
                                     args=(q, fill, trail_text, on_update, t0), daemon=True).start()
                elif fill:
                    merged = self._fill_gaps(fill)
                    if merged is not fill:
                        self._upsert(merged)
                        row = self._row(b)

        if row:
            self._record_search(q, b)
            return self._result(q, row, status or self._status_of(row), message, trail_text,
                                time.time() - t0, refreshing)
        result.update({"message": message or "No data found.", "trail": trail_text,
                       "elapsed": time.time() - t0})
        return result

    def get_record(self, text: str) -> dict:
        """Stored record for a searched number: no network, no history side-effects."""
        q = normalize_query(text)
        row = self._row(q[:6])
        if not row:
            scheme, lengths = detect_scheme(q)
            return {"query": q, "bin": q[:6], "found": False, "status": "", "message": "Not stored on this device.",
                    "trail": "", "elapsed": 0.0, "refreshing": False, "saved": False, "note": "",
                    "detected_scheme": scheme, "expected_length": lengths, "flag": flag_emoji("")}
        return self._result(q, row, self._status_of(row))

    # -- saved / history ----------------------------------------------
    def save_query(self, text: str, note: str = "") -> bool:
        """Save the number exactly as searched (up to 8 digits) with a note and the save time."""
        q = normalize_query(text)
        if len(q) < 6 or not self._row(q[:6]):
            return False
        self._q("INSERT OR IGNORE INTO saved (query, bin, note, saved_at) VALUES (?,?,?,?)",
                (q, q[:6], "", self._now()))
        self._q("UPDATE saved SET note=? WHERE query=?", ((note or "").strip(), q))
        return True

    def unsave_query(self, text: str):
        self._q("DELETE FROM saved WHERE query=?", (normalize_query(text),))

    @staticmethod
    def _like(s: str) -> str:
        return "%" + re.sub(r"[%_]", " ", s.strip().upper()) + "%"

    def saved(self, query: str = "", limit: int = 40, offset: int = 0) -> list[dict]:
        sql = (f"SELECT {BIN_SELECT}, s.query AS query, s.note AS note, s.saved_at AS saved_at, "
               f"1 AS saved FROM saved s JOIN bins b ON b.bin = s.bin")
        p: list = []
        if query.strip():
            like = self._like(query)
            sql += (" WHERE s.query LIKE ? OR UPPER(b.bank) LIKE ? OR UPPER(s.note) LIKE ? "
                    "OR UPPER(b.country) LIKE ? OR UPPER(b.scheme) LIKE ?")
            p += [like] * 5
        return self._q(sql + " ORDER BY s.saved_at DESC, s.rowid DESC LIMIT ? OFFSET ?", p + [limit, offset])

    def saved_count(self) -> int:
        return self._q("SELECT COUNT(*) AS n FROM saved", one=True)["n"]

    def history(self, limit: int = 40) -> list[dict]:
        return self._q(
            f"SELECT {BIN_SELECT}, s.query AS query, s.ts AS searched_at, "
            f"EXISTS(SELECT 1 FROM saved v WHERE v.query = s.query) AS saved "
            f"FROM searches s JOIN bins b ON b.bin = s.bin ORDER BY s.ts DESC LIMIT ?", (limit,))

    def clear_history(self):
        self._q("DELETE FROM searches")

    # -- search / cascading filters -----------------------------------
    def _distinct(self, col: str, where: dict, like: str = "", limit: int = 1500) -> list[str]:
        assert col in FILTER_COLUMNS
        sql = (f"SELECT DISTINCT {col} AS v FROM bins WHERE {col} IS NOT NULL "
               f"AND {col} NOT IN ('', 'N/A', 'UNKNOWN')")
        params: list = []
        for c, v in where.items():
            if v:
                assert c in FILTER_COLUMNS
                sql += f" AND {c}=?"
                params.append(v)
        if like.strip():
            sql += f" AND UPPER({col}) LIKE ?"
            params.append(self._like(like))
        return [r["v"] for r in self._q(sql + f" ORDER BY {col} LIMIT ?", params + [limit])]

    def facets(self, country: str = "", scheme: str = "", bank: str = "", type_: str = "",
               bank_like: str = "") -> dict:
        """Options for bincheck.io-style cascading filters:
        Country -> Brand(network) -> Bank -> Type -> Level. Each list depends on the
        selections to its left."""
        countries = self._q("SELECT country_code AS cc, MIN(country) AS name FROM bins "
                            "WHERE country_code NOT IN ('', 'N/A') GROUP BY country_code ORDER BY name")
        return {
            "countries": [(r["cc"], r["name"]) for r in countries],
            "schemes": self._distinct("scheme", {"country_code": country}),
            "banks": self._distinct("bank", {"country_code": country, "scheme": scheme}, bank_like),
            "types": self._distinct("type", {"country_code": country, "scheme": scheme, "bank": bank}),
            "levels": self._distinct("brand", {"country_code": country, "scheme": scheme,
                                               "bank": bank, "type": type_}),
        }

    def _filter_sql(self, country, scheme, bank, type_, level):
        sql, p = " FROM bins WHERE 1=1", []
        for col, val in (("country_code", country), ("scheme", scheme), ("bank", bank),
                         ("type", type_), ("brand", level)):
            if val:
                sql += f" AND {col}=?"
                p.append(val)
        return sql, p

    def count_filters(self, country="", scheme="", bank="", type_="", level="") -> int:
        sql, p = self._filter_sql(country, scheme, bank, type_, level)
        return self._q("SELECT COUNT(*) AS n" + sql, p, one=True)["n"]

    def search_filters(self, country="", scheme="", bank="", type_="", level="",
                       limit: int = 40, offset: int = 0) -> list[dict]:
        sql, p = self._filter_sql(country, scheme, bank, type_, level)
        rows = self._q("SELECT *" + sql + " ORDER BY bank, bin LIMIT ? OFFSET ?", p + [limit, offset])
        for r in rows:
            r["query"] = r["bin"]
        return rows

    # -- offline database (CSV import / download) ---------------------
    HEADER_ALIASES = {
        "bin": ("bin", "iin", "bin_iin"),
        "scheme": ("scheme", "brand", "network", "card_brand", "cardscheme"),
        "type": ("type", "card_type", "cardtype"),
        "brand": ("category", "level", "tier", "cardtier", "card_level", "product"),
        "bank": ("issuer", "bank", "bank_name", "issuer_name"),
        "phone": ("issuerphone", "bank_phone", "phone"),
        "url": ("issuerurl", "bank_url", "url", "website"),
        "country_code": ("isocode2", "country_code", "alpha2", "a2", "country_iso"),
        "country_a3": ("isocode3", "alpha3", "a3"),
        "country": ("countryname", "country", "country_name"),
    }

    def _map_headers(self, headers: dict) -> dict:
        mapping, used = {}, set()
        for field, aliases in self.HEADER_ALIASES.items():
            for a in aliases:
                if a in headers and headers[a] not in used:
                    mapping[field] = headers[a]
                    used.add(headers[a])
                    break
        return mapping

    @staticmethod
    def _clean_field(field: str, raw) -> str:
        if field in ("phone", "url"):
            return _txt(raw)
        if field == "country_code":
            return _up(raw, "")
        if field in ("prepaid", "commercial"):
            return "Unknown"
        return _up(raw)

    def import_csv(self, path: str, progress=None) -> dict:
        """Import a public BIN list. Existing (live) rows are never overwritten."""
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("The CSV file is empty.")
            headers = {h.strip().lower(): h for h in reader.fieldnames if h}
            mapping = self._map_headers(headers)
            if "bin" not in mapping:
                raise ValueError("The CSV needs a BIN or IIN column.")
            cols = ["bin"] + FIELDS + ["source", "fetched_at"]
            sql = f"INSERT OR IGNORE INTO bins ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})"
            total, batch, now = 0, [], self._now()
            self._drop_bulk_indexes()                 # much faster bulk insert; rebuilt below
            try:
                with closing(sqlite3.connect(self.db_path, timeout=60)) as conn:
                    before = conn.total_changes
                    for row in reader:
                        total += 1
                        digits = re.sub(r"\D", "", row.get(mapping["bin"]) or "")[:6]
                        if len(digits) < 6:
                            continue
                        vals = [digits]
                        for fld in FIELDS:
                            vals.append(self._clean_field(fld, row.get(mapping[fld]) if fld in mapping else ""))
                        batch.append(vals + [IMPORT_SOURCE, now])
                        if len(batch) >= 5000:
                            conn.executemany(sql, batch)
                            batch = []
                            if progress and total % 25000 < 5000:
                                progress(f"Importing... {total:,} rows")
                    if batch:
                        conn.executemany(sql, batch)
                    conn.commit()
                    added = conn.total_changes - before
            finally:
                if progress:
                    progress("Building search index...")
                self._create_bulk_indexes()
        return {"rows": total, "added": added}

    def download_dataset(self, progress=None, url: str = DATASET_URL) -> dict:
        """Download the public BIN list to app storage and import it."""
        tmp = os.path.join(os.path.dirname(self.db_path), "bin-list-data.csv.part")
        try:
            try:
                r = _http_get(url, {"User-Agent": USER_AGENT}, (5, 30), stream=True)
                if r.status_code != 200:
                    raise RuntimeError(f"Download failed (HTTP {r.status_code}).")
                size = 0
                with open(tmp, "wb") as f:
                    for chunk in r.iter_content(256 * 1024):
                        if chunk:
                            f.write(chunk)
                            size += len(chunk)
                            if progress:
                                progress(f"Downloading... {size / 1e6:.1f} MB")
            except requests.RequestException as exc:
                raise RuntimeError("Download failed. Check your internet connection.") from exc
            result = self.import_csv(tmp, progress)
            self.set_setting("dataset_loaded", self._now())
            return result
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # -- TXT export ----------------------------------------------------
    SEP = "-" * 53

    @staticmethod
    def _entry_lines(d: dict, note: str = "") -> list[str]:
        scheme = SCHEME_DISPLAY.get(d.get("scheme", ""), d.get("scheme") or "N/A")
        info = " - ".join(x for x in (d.get("brand"), d.get("type"), scheme) if not _is_na(x))
        country = d.get("country") or "N/A"
        return [
            f"\U0001F517 TYPE \u279C {scheme}",
            f"\U0001F3E6 BANK \u279C {d.get('bank') or 'N/A'}",
            f"\U0001F30D COUNTRY \u279C {flag_emoji(d.get('country_code', ''))} {country}",
            f"\U0001F4B3 INFO \u279C {info or 'N/A'}",
            f"\u2139\uFE0F NOTE \u279C {(note or d.get('note') or '').strip() or '-'}",
        ]

    def format_entry(self, d: dict, note: str = "") -> str:
        """Block used by the card's 'copy details' button."""
        return "\n".join([d.get("query") or d["bin"]] + self._entry_lines(d, note))

    def format_export(self, entries: list[dict]) -> str:
        """TXT export. Each entry shows the number exactly as searched (up to 8 digits).
        Entries saved in the same minute share one DATE/TIME header."""
        now = datetime.now()
        out, last_key = [], None
        for e in entries:
            date, time_ = _fmt_time(e.get("saved_at"), now)
            key = (date, time_)
            if key != last_key:
                out += [self.SEP, f"DATE : {date}", f"TIME : {time_}", self.SEP]
                last_key = key
            else:
                out.append(self.SEP)
            out.append(e.get("query") or e["bin"])
            out += self._entry_lines(e)
        return "\n".join(out) + "\n"

    def export_text_file(self, text: str, prefix: str = "bin_atlas") -> tuple[str, str]:
        folder = os.path.join(os.path.dirname(self.db_path), "exports")
        os.makedirs(folder, exist_ok=True)
        name = f"{prefix}_{datetime.now():%Y%m%d_%H%M%S}.txt"
        path = os.path.join(folder, name)
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        return path, name
