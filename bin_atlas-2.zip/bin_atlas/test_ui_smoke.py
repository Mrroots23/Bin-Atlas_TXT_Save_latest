"""UI smoke test with a stub `flet` (no Flet install needed).
Clicks through every tab and action to catch NameErrors / wrong wiring.
It cannot check real Flet rendering - test the APK on a device for that."""
import os, sys, tempfile, types, unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["FLET_APP_STORAGE_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, HERE)


class Ctl:
    def __init__(self, *a, **kw):
        self.args = a
        self.__dict__.update(kw)
        self.controls = list(a[0]) if a and isinstance(a[0], list) else list(kw.get("controls", []) or [])
        self.value = kw.get("value", None)


def make_ft():
    ft = mock.MagicMock()
    for name in ("Container", "Column", "Row", "Text", "TextField", "Switch", "Dropdown", "Image",
                 "ProgressBar", "ProgressRing", "Icon", "IconButton", "TextButton", "SafeArea",
                 "NavigationBar", "NavigationBarDestination", "AlertDialog", "SnackBar", "FilePicker"):
        setattr(ft, name, Ctl)
    ft.dropdown = types.SimpleNamespace(Option=Ctl)
    return ft


def walk(c, seen=None):
    seen = seen if seen is not None else set()
    if id(c) in seen or not isinstance(c, Ctl):
        return
    seen.add(id(c))
    yield c
    for ch in list(c.controls) + list(c.args):
        if isinstance(ch, list):
            for x in ch:
                yield from walk(x, seen)
        else:
            yield from walk(ch, seen)
    for attr in ("content", "title", "actions", "options"):
        v = getattr(c, attr, None)
        if isinstance(v, list):
            for x in v:
                yield from walk(x, seen)
        elif isinstance(v, Ctl):
            yield from walk(v, seen)


class Page:
    def __init__(self):
        self.controls, self.overlay, self.opened = [], [], []
        self.navigation_bar = None
        self.clipboard = ""

    def add(self, *c): self.controls.extend(c)
    def clean(self): self.controls.clear()
    def update(self): pass
    def open(self, c): self.opened.append(c)
    def close(self, c): pass
    def run_thread(self, fn, *a): fn(*a)
    def set_clipboard(self, t): self.clipboard = t


def texts(root):
    out = []
    for c in walk(root):
        if c.__class__ is Ctl and c.args and isinstance(c.args[0], str):
            # a Text whose .value was changed later (e.g. a counter) shows the new value
            out.append(c.value if isinstance(c.value, str) and c.value else c.args[0])
    return out


def click(root, label):
    for c in walk(root):
        if getattr(c, "on_click", None) and (c.args[:1] == (label,) or label in texts(c)):
            c.on_click(None)
            return True
    raise AssertionError(f"no clickable '{label}'")


def by_label(root, start):
    return next(c for c in walk(root) if c.__class__ is Ctl and str(getattr(c, "label", "")).startswith(start))


def goto(page, i):
    page.navigation_bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=i)))


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True}, "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB", "phone": "+1", "url": "x.com"}}
CSV = ("BIN,Brand,Type,Category,Issuer,IssuerPhone,IssuerUrl,isoCode2,isoCode3,CountryName\n"
       "011300,LOCAL BRAND,DEBIT,PROPRIETARY ATM,BDO UNIBANK INC,,,PH,PHL,PHILIPPINES\n"
       "012004,VISA,CREDIT,GOLD,STATE BANK OF INDIA,,,IN,IND,INDIA\n")


def fake_net(url, headers=None, timeout=None, stream=False):
    if "raw.githubusercontent" in url:
        class R:
            status_code = 200
            def iter_content(self, n): yield CSV.encode()
        return R()
    if "binlist.io" in url:
        m = mock.Mock(status_code=200); m.json.return_value = BINLIST_OK; return m
    return mock.Mock(status_code=500)


class Smoke(unittest.TestCase):
    def start(self, ft):
        sys.modules.pop("main", None)
        import main as app
        page = Page()
        app.main(page)
        self.assertIsNotNone(page.navigation_bar, "app failed to start: " + " ".join(texts(page.controls[0])))
        return app, page, page.controls[0]

    def test_full_flow(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine._http_get", fake_net), \
                mock.patch("time.sleep"), mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)

            # --- Lookup: no top note field; type 11 digits -> only 8 are used, no pop-up
            self.assertFalse(any(str(getattr(c, "label", "")).startswith("Note to save") for c in walk(root)))
            by_label(root, "BIN").value = "52792622911"
            click(root, "Look up")
            shown = " ".join(texts(root))
            self.assertIn("52792622", shown); self.assertIn("BIN 527926", shown); self.assertIn("REVOLUT BANK UAB", shown)
            self.assertNotIn("5279262291", shown)
            self.assertEqual(page.opened, [])                                   # no "first six digits" pop-up
            for gone in ("Continent", "Dial code", "Prepaid", "Commercial", "Website", "Issuer phone"):
                self.assertNotIn(gone, shown)
            for kept in ("Scheme", "Type", "Tier / level", "Luhn", "Issuer / bank", "Country", "Currency"):
                self.assertIn(kept, shown)

            # --- copy: button and small icon both copy the number searched, not the 6-digit BIN
            click(root, "Copy"); self.assertEqual(page.clipboard, "52792622")
            page.clipboard = ""
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "Copy this number").on_click(None)
            self.assertEqual(page.clipboard, "52792622")
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "Copy full details").on_click(None)
            self.assertIn("52792622\n", page.clipboard); self.assertIn("TYPE", page.clipboard)

            # --- Save with the note that sits under the card
            by_label(root, "Note - saved").value = "client A"
            click(root, "Save")
            from engine import BinEngine
            self.assertEqual([(r["query"], r["bin"], r["note"]) for r in BinEngine().saved()],
                             [("52792622", "527926", "client A")])
            self.assertIn("Update note", " ".join(texts(root)))

            # --- Banks: download the offline database, then every country appears
            goto(page, 1)
            click(root, "Download BIN database")
            dds = {d.label: d for d in walk(root) if d.__class__ is Ctl and getattr(d, "label", "") in ("Country", "Brand", "Bank", "Type", "Level")}
            self.assertEqual(list(dds), ["Country", "Brand", "Bank", "Type", "Level"])
            keys = {o.key for o in dds["Country"].options}
            self.assertTrue({"IT", "PH", "IN", "US", "SA"} <= keys)
            dds["Country"].value = "PH"; dds["Country"].on_change(None)
            self.assertEqual([o.key for o in dds["Bank"].options], ["__all__", "BDO UNIBANK INC"])
            click(root, "Search")
            self.assertIn("011300", " ".join(texts(root))); self.assertIn("1 BIN(s) found", " ".join(texts(root)))
            click(root, "Export TXT")
            self.assertIn("DATE : ", page.clipboard); self.assertIn("BDO UNIBANK INC", page.clipboard)
            click(root, "Reset"); self.assertEqual(dds["Country"].value, "__all__")

            # --- Learn: multi-number Luhn
            goto(page, 2)
            self.assertIn("3 pass · 3 fail", " ".join(texts(root)))

            # --- Saved: exact number + gray BIN + note; tap opens details in place; TXT export
            goto(page, 3)
            t = " ".join(texts(root))
            self.assertIn("52792622", t); self.assertIn("BIN 527926", t); self.assertIn("\u270E client A", t)
            tile = next(c for c in walk(root) if c.__class__ is Ctl and getattr(c, "on_click", None) and "\u270E client A" in texts(c))
            tile.on_click(None)
            self.assertIn("BIN details", " ".join(texts(root)))
            goto(page, 3)
            click(root, "Export TXT")
            self.assertIn("52792622\n\U0001F517 TYPE \u279C VISA", page.clipboard)
            self.assertIn("\u2139\uFE0F NOTE \u279C client A", page.clipboard)
            self.assertNotIn("5279262291", page.clipboard)

    def test_settings_dialog(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("time.sleep"), \
                mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "API keys & sources").on_click(None)
            dlg = page.opened[-1]
            handy = by_label(dlg, "HandyAPI")
            handy.value = "HAS-" + "q" * 20
            next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("SECRET" in s for s in texts(dlg)))
            handy.value = "PUB-" + "q" * 20
            with mock.patch("engine._http_get", return_value=mock.Mock(status_code=401)):
                next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("key rejected" in s for s in texts(dlg)))
            self.assertTrue(any("venelinkochev" in s for s in texts(dlg)))      # CC BY credit is shown


if __name__ == "__main__":
    unittest.main()
